#!/bin/bash

export SUMO_HOME=/packages/sumo_0.31.0
export SUMO_TOOLS=$SUMO_HOME/tools

$SUMO_HOME/bin/sumo --save-template sumo.cfg
$SUMO_HOME/bin/netconvert --save-template netconvert.cfg
$SUMO_HOME/bin/duarouter --save-template duarouter.cfg
$SUMO_HOME/bin/od2trips --save-template od2trips.cfg
